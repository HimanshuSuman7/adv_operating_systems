#ifndef _CHILD_FUNC
#define _CHILD_FUNC

extern void parent_spawns_child(int get_even, int get_odd, int tree_height);
#endif
